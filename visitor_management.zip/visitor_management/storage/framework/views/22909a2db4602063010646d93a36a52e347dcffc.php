<!DOCTYPE html>
<html>
<head>
    <title>Visitor Management System in Laravel</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>" />
    
    <script src="<?php echo e(asset('js/form.js')); ?>"></script>
    
    
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>

    

    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.2/moment.min.js"></script>
    <script src="https://cdn.datatables.net/datetime/1.1.2/js/dataTables.dateTime.min.js"></script>

    <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css" />
    <link rel="stylesheet" href="https://cdn.datatables.net/datetime/1.1.2/css/dataTables.dateTime.min.css" />
    <meta charset=utf-8 />
</head>
<body>

    <?php if(auth()->guard()->guest()): ?>

    <h1 class="mt-4 mb-5 text-center">Visitor Management System</h1>

    <?php echo $__env->yieldContent('content'); ?>

    <?php else: ?>

    <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap5.min.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/form.css')); ?>">
    
    
    
    
    
    
    
    

    

    <header class="navbar navbar-dark fixed-top bg-dark flex-md-nowrap p-0 shadow">
        <img id="imgPrevie"  class="fieldlabels col-md-1 mr-1" height="40" src="<?php echo e(asset('uploads/'.'1/'.'123.jpg')); ?>" alt="Preview">
        <a class="navbar-brand col-md-1 col-lg-2 me-0 px-3"  href="#">Visitor Management</a>
        <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="navbar-nav">
            <div class="nav-item text-nowrap">
                <a class="nav-link px-3" href="#">Welcome, <?php echo e(Auth::user()->email); ?></a>
            </div>
        </div>
    </header>

    <div class="container-fluid">
        <div class="row">
            <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(Request::segment(1) == 'information' ? 'active' : ''); ?>"   aria-current="page" href="/information">Information</a>
                            <hr style="margin:0px 0px">
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(Request::segment(1) == 'profile' ? 'active' : ''); ?>" aria-current="page" href="/profile">Profile</a>
                            <hr style="margin:0px 0px; padding:1px 1px;">
                        </li>
                        <?php if(Auth::user()->type == 'Admin'): ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(Request::segment(1) == 'settings' ? 'active' : ''); ?>" aria-current="page" href="/settings">Settings</a>
                            <hr style="margin:0px 0px; padding:1px 1px;">
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(Request::segment(1) == 'sub_user' ? 'active' : ''); ?>" aria-current="page" href="/sub_user">Sub User</a>
                            <hr style="margin:0px 0px; padding:1px 1px;">
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(Request::segment(1) == 'department' ? 'active' : ''); ?>" aria-current="page" href="/department">Department</a>
                            <hr style="margin:0.2px 0px; padding:0px 0px;">
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(Request::segment(1) == 'employee' ? 'active' : ''); ?>" aria-current="page" href="/employee">Employee</a>
                            <hr style="margin:0px 0px; padding:1px 1px;">
                        </li>
                        <?php endif; ?>

                        <li class="nav-item">
                            <a class="nav-link <?php echo e(Request::segment(1) == 'visitor' ? 'active' : ''); ?>" href="/visitor">Visitor</a>
                            <hr style="margin:0px 0px; padding:1px 1px;">
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('logout')); ?>">Logout</a>
                            <hr style="margin:0px 0px; padding:1px 1px;">
                        </li>

                    </ul>

                </div>
            </nav>
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <!--<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">!-->
                    
                <?php echo $__env->yieldContent('content'); ?>

                <!--</div>!-->
            </main>
        </div>
    </div>

    <?php endif; ?>

    <script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
    <footer style="text-align: center;">
        <hr>
        <p>Visitor Management System
            &copy; Copyright 2022 Roshan Khan
        </p>
      </footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\visitor_management\resources\views/dashboard.blade.php ENDPATH**/ ?>