<?php $__env->startSection('content'); ?>


    <?php if(session()->has('employee_update')): ?>
    <div class="alert alert-success mt-5">
        <?php echo e(session()->get('employee_update')); ?>

    </div>
    <?php endif; ?>
<?php if(session()->has('employee_register')): ?>
    <div class="alert alert-success mt-5">
        <?php echo e(session()->get('employee_register')); ?>

    </div>
    <?php endif; ?>

<h2 class="mt-5">Employee Management</h2>
<nav aria-label="breadcrumb">
  	<ol class="breadcrumb">
    	<li class="breadcrumb-item"><a href="/information">Dashboard</a></li>
    	<li class="breadcrumb-item active">Employee</li>
  	</ol>
</nav>
<div class="mt-4 mb-4">
	<div class="card">
		<div class="card-header">
			<div class="row">
				<div class="col col-md-8">Employee Management</div>
               
				<div class="col col-md-4"  >
                    <a href="employee/add" class="btn btn-success btn-sm float-end">Add</a>
				</div>
			</div>
		</div>
		<div class="card-body">
			<div class="table-responsive">
				<table class="table table-bordered" id="employee_table">
					<thead>
						<tr>
							<th>Employee Name</th>
							<th>Employee Email</th>
							<th>Employee Department</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody></tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<script>
$(document).ready(function(){

	var table = $('#employee_table').DataTable({

		processing:true,
		serverSide:true,
		ajax:"<?php echo e(route('employee.fetchall')); ?>",
		columns:[
			{
				data:'name',
				name: 'Name'
			},
			{
				data: 'email',
				name: 'email'
			},
			{
				data:'department_name',
				name:'department_name'
			},

			{
				data:'action',
				name:'action',
				orderable:false
			}
		]
	});

});


</script>

<script>
    $("document").ready(function(){
        setTimeout(function(){
           $("div.alert").remove();
        }, 5000 ); // 5 secs

    });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\visitor_management\resources\views/employee.blade.php ENDPATH**/ ?>