<?php $__env->startSection('content'); ?>

<?php if(session()->has('settings')): ?>
<div class="alert alert-success mt-5">
    <?php echo e(session()->get('settings')); ?>

</div>
<?php endif; ?>
<h2 class="mt-5">Settings</h2>
<nav aria-label="breadcrumb">
  	<ol class="breadcrumb">
    	<li class="breadcrumb-item"><a href="/information">Dashboard</a></li>
    	<li class="breadcrumb-item active">Settings</li>
  	</ol>
</nav>

<div class="row mt-4">
	<div class="col-md-4">
		<div class="card">
			<div class="card-header">Add New Logo</div>
			<div class="card-body">
				<form method="POST" action="<?php echo e($url); ?>"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
    <label for="logo_upload" class="form-control"><?php echo e(__('Upload your logo')); ?></label>


    <input onchange="temp_url(this)" type="file"  id="myFileInput" class="form-control" name="logo_upload">
    <?php if($logo->folder_path != ""): ?>{
    <h4 id="imgPreview_e_11" class="form-control">uploads/<?php echo e($logo->folder_path); ?></h4>
    <img id="imgPreview_e"  class="form-control" height="80" src="<?php echo e(asset('uploads/'.$logo->folder_path)); ?>" alt="Preview">
    }
    <?php endif; ?>
    <div class="col-md-4">
        <img id="imgPreview"  class="form-control" height="80" src="<?php echo e(asset('uploads/'.$logo->folder_path)); ?>" alt="Preview">
    </div>
    <?php $__errorArgs = ['logo_upload'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="form-group mb-3">
        <input type="submit" class="btn btn-primary" value="Save" />
    </div>
</form>
</div>
</div>
</div>
</div>


 <script>
            function temp_url(e){
            $("#imgPreview_e").hide();
            $("#imgPreview_e_11").hide();
		const reader = new FileReader();
        console.log(reader);
		reader.addEventListener("load",()=>{
			localStorage.setItem("recent-image",reader.result);
            document.getElementById("imgPreview").setAttribute("src",reader.result);
		});
        console.log(e.files[0]);
        reader['readAsDataURL'](e.files[0]);
		// reader.readDataURL(e.files[0]);
    }

	document.addEventListener("DOMContentLoaded",() =>{
   	const recentImageDataUrl=localStorage.getItem("recent-image");
   	if(recentImageDataUrl){
   		document.querySelector("imgPreview").setAttribute("src",recentImageDataUrl);
   	}
	});
 </script>
 <script>
    $("document").ready(function(){
        setTimeout(function(){
           $("div.alert").remove();
        }, 5000 ); // 5 secs

    });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\visitor_management\resources\views/settings.blade.php ENDPATH**/ ?>