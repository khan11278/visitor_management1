<?php $__env->startSection('content'); ?>


<h2 class="mt-5">Employee Management</h2>
<nav aria-label="breadcrumb">
  	<ol class="breadcrumb">
    	<li class="breadcrumb-item"><a href="/information">Dashboard</a></li>
    	<li class="breadcrumb-item active"><a href="/employee">Employee Add</a></li>
    	
  	</ol>
</nav>
<div class="row mt-4">
	<div class="col-md-4">
		<div class="card">
			<div class="card-header">Add New User</div>
			<div class="card-body">
				<form method="POST" action="<?php echo e($url); ?>">
					<?php echo csrf_field(); ?>
					<div class="form-group mb-3">
		        		<label><b>Employee Name *</b></label>
		        		<input type="text" name="name" class="form-control" value="<?php echo e(old('name', $employee->name)); ?>" placeholder="Name" />
		        		<?php if($errors->has('name')): ?>
		        		<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
		        		<?php endif; ?>
		        	</div>
		        	<div class="form-group mb-3">
		        		<label><b>Employee Email *</b></label>
		        		<input type="text" name="email" class="form-control" value="<?php echo e(old('name', $employee->email)); ?>" placeholder="Email">
		        		<?php if($errors->has('email')): ?>
		        			<span class="text-danger"><?php echo e($errors->first('email')); ?></span>
		        		<?php endif; ?>
		        	</div>
                    
                    <div class="form-group mb-3">
		        		<label><b>Employee department *</b></label>
                        <br>
                        <p fontsize="10px;">
                        <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		        		 <small><?php echo e($dept->department_name); ?></small>&nbsp;
                        <input name="dept[]"  type="checkbox" <?php echo e(in_array($dept->department_name, $emp_dept) ? 'checked' : ''); ?> value="<?php echo e($dept->id); ?>">

                        <?php if($errors->has('dept')): ?>
		        			<span class="text-danger"><?php echo e($errors->first('dept')); ?></span>
		        		<?php endif; ?>
                            <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
		        	</div>
		        	<div class="form-group mb-3">
		        		<input type="submit" class="btn btn-primary" value="Add" />
		        	</div>
				</form>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\visitor_management\resources\views/employee_add.blade.php ENDPATH**/ ?>