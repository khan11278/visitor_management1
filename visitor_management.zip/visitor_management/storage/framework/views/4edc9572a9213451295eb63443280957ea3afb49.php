<?php $__env->startSection('content'); ?>


    <?php if(session()->has('employee_update')): ?>
    <div class="alert alert-success mt-5">
        <?php echo e(session()->get('employee_update')); ?>

    </div>
    <?php endif; ?>
<?php if(session()->has('employee_register')): ?>
    <div class="alert alert-success mt-5">
        <?php echo e(session()->get('employee_register')); ?>

    </div>
    <?php endif; ?>

<h2 class="mt-5">Employee Management</h2>
<nav aria-label="breadcrumb">
  	<ol class="breadcrumb">
    	<li class="breadcrumb-item"><a href="/information">Dashboard</a></li>
    	<li class="breadcrumb-item active">Employee</li>
  	</ol>
</nav>
<div class="mt-4 mb-4">
	<div class="card">
		<div class="card-header">
			<div class="row">
				<div class="col col-md-8">Employee Management</div>
               
				<div class="col col-md-4"  >
                    <a href="employee/add" class="btn btn-success btn-sm float-end">Add</a>
				</div>
			</div>
		</div>
		<div class="card-body">
			<div class="table-responsive">

                <table class="table table-bordered" id="employee_table1">

                    <thead>
						<tr>
							<th>Employee Name</th>
							<th>Employee Email</th>
							<th>Employee Department</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
                        <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($emp->name); ?></td>
                            <td><?php echo e($emp->email); ?></td>
                            <td><?php echo e($emp->department['department_name']); ?></td>
                            <td><a href="/employee/edit/<?php echo e($emp->id); ?>" class="btn btn-primary btn-sm">Edit</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    
				</table>
			</div>
		</div>
	</div>
</div>


<script>
    // $(document).ready( function () {
    // $('#employee_table').DataTable();
    // } );
    $("document").ready(function(){
        $('#employee_table1').DataTable();

        setTimeout(function(){
           $("div.alert").remove();
        }, 5000 ); // 5 secs

    //    var $emp= $('#employee_table').DataTable();
    //    console.log($emp);
        // $('#employee_table').DataTable();
    });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\visitor_management\resources\views/employee.blade.php ENDPATH**/ ?>