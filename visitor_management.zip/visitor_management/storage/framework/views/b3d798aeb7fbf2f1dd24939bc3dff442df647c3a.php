
<?php $__env->startSection('content'); ?>
<h2 class="mt-3">Profile</h2>
<nav aria-label="breadcrumb">
  	<ol class="breadcrumb">
    	<li class="breadcrumb-item"><a href="/dashboard">Dashboard</a></li>
    	<li class="breadcrumb-item active">Profile</li>
  	</ol>
</nav>
<div class="row mt-4">
	<?php if(session()->has('success')): ?>
	<div class="alert alert-success">
		<?php echo e(session()->get('success')); ?>

	</div>

	<?php endif; ?>
	<div class="col-md-4">
		<div class="card">
			<div class="card-header">Edit User</div>
			<div class="card-body">
				<form method="post" action="<?php echo e(route('profile.edit_validation')); ?>">
					<?php echo csrf_field(); ?>
					<div class="form-group mb-3">
		        		<label><b>User Name</b></label>
		        		<input type="text" name="name" class="form-control" placeholder="name" value="<?php echo e($data->name); ?>" />
		        		<?php if($errors->has('name')): ?>
		        		<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
		        		<?php endif; ?>
		        	</div>
		        	<div class="form-group mb-3">
		        		<label><b>User Email</b></label>
		        		<input type="text" name="email" class="form-control" placeholder="Email" value="<?php echo e($data->email); ?>" />
		        		<?php if($errors->has('email')): ?>
		        		<span class="text-danger"><?php echo e($errors->has('email')); ?></span>
		        		<?php endif; ?>
		        	</div>
		        	<div class="form-group mb-3">
		        		<label><b>Password</b></label>
		        		<input type="password" name="password" class="form-control" placeholder="Password" />
		        	</div>
		        	<div class="form-group mb-3">
		        		<input type="submit" class="btn btn-primary" value="Edit" />
		        	</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tutorial\visitor_management\resources\views/profile.blade.php ENDPATH**/ ?>