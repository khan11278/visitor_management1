<?php $__env->startSection('content'); ?>

<?php if(session()->has('success1')): ?>
		<div class="alert alert-success mt-5">
			<?php echo e(session()->get('success1')); ?>

		</div>
	<?php endif; ?>

<h2 class="mt-5">Visitor Management</h2>
<nav aria-label="breadcrumb">
  	<ol class="breadcrumb">
    	<li class="breadcrumb-item"><a href="/information">Dashboard</a></li>
    	<li class="breadcrumb-item active">Visitor Management</li>
  	</ol>
</nav>
<div class="mt-4 mb-4">
	<div class="card">
		<div class="card-header">
			<div class="row">
				<div class="col col-md-8">Visitor Management</div>
               
				<div class="col col-md-4" <?php if(Auth::user()->type=='Admin'): ?><?php echo e("hidden"); ?><?php endif; ?> >
                    <a href="/visitor/add" class="btn btn-success btn-sm float-end">Add</a>
				</div>
			</div>
		</div>
		<div class="card-body">
			<div class="table-responsive">
				<table class="table table-bordered" id="visitor_table">
					<thead>
						<tr>
							<th>Visitor Name</th>
                            <th>Visitor Mobile Number</th>
                            <th>Visitor Token</th>
							<th>Meet Person Name</th>
                            <th>Department</th>
							<th>In Time</th>
							<th>Out Time</th>
							<th>Status</th>
							<th>Enter By</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody></tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<script>
$(document).ready(function(){

	var table = $('#visitor_table').DataTable({

		processing:true,
		serverSide:true,
		ajax:"<?php echo e(route('visitor.fetchall')); ?>",
		columns:[
			{
				data:'visitor_name',
				name: 'visitor_name'
			},
            {
				data:'visitor_mobile_no',
				name:'visitor_mobile_no'
			},
            {
				data:'visitor_token',
				name:'visitor_token'
			},
			{
				data: 'visitor_meet_person_name',
				name: 'visitor_meet_person_name'
			},
			{
				data:'visitor_department',
				name:'visitor_department'
			},
			{
				data:'visitor_enter_time',
				name: 'visitor_enter_time'
			},
			{
				data:'visitor_out_time',
				name:'visitor_out_time'
			},
			{
				data:'visitor_status',
				name:'visitor_status'
			},
			{
				data:'name',
				name:'name'
			},


			{
				data:'action',
				name:'action',
				orderable:false
			}
		]
	});

});

$("document").ready(function(){
    setTimeout(function(){
       $("div.alert").remove();
    }, 5000 ); // 5 secs

});

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\visitor_management\resources\views//visitor.blade.php ENDPATH**/ ?>