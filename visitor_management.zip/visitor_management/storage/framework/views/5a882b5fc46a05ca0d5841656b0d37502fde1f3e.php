<?php $__env->startSection('content'); ?>

	<main class="login-form">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-4">

					<?php if(session()->has('error')): ?>

					<div class="alert alert-danger">
						<?php echo e(session()->get('error')); ?>

					</div>

					<?php endif; ?>

					<div class="card mt-5" >
						<h3 class="card-header text-center">Login</h3>

						<div class="card-body">
							<form method="post" action="<?php echo e(route('login.custom')); ?>">

								<?php echo csrf_field(); ?>

								<div class="form-group mb-3">
									<input type="text" name="email" class="form-control" placeholder="Email" />

									<?php if($errors->has('email')): ?>
									<span class="text-danger"><?php echo e($errors->first('email')); ?></span>
									<?php endif; ?>
								</div>

								<div class="form-group mb-3">
									<input type="password" name="password" class="form-control" placeholder="Password" />

									<?php if($errors->has('password')): ?>
									<span class="text-danger"><?php echo e($errors->first('password')); ?></span>
									<?php endif; ?>
								</div>

								<div class="d-grid mx-auto">
									<button type="submit" class="btn btn-dark btn-block">Login</button>
								</div>

							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</main>

    <script>
        $("document").ready(function(){
            setTimeout(function(){
               $("div.alert").remove();
            }, 5000 ); // 5 secs

        });
        </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\visitor_management\resources\views/auth/login.blade.php ENDPATH**/ ?>