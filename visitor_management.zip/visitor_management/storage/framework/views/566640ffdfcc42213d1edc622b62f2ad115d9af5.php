<?php $__env->startSection('content'); ?>

<?php if(session()->has('success1')): ?>
		<div class="alert alert-success mt-5">
			<?php echo e(session()->get('success1')); ?>

		</div>
	<?php endif; ?>

<h2 class="mt-5">Visitor Management</h2>
<nav aria-label="breadcrumb">
  	<ol class="breadcrumb">
    	<li class="breadcrumb-item"><a href="/information">Dashboard</a></li>
    	<li class="breadcrumb-item active">Visitor Management</li>
  	</ol>
</nav>
<div class="mt-4 mb-4">
	<div class="card">
		<div class="card-header">
			<div class="row">
				<div class="col col-md-8">Visitor Management</div>
               
				<div class="col col-md-4" <?php if(Auth::user()->type=='Admin'): ?><?php echo e("hidden"); ?><?php endif; ?> >
                    <a href="/visitor/add" class="btn btn-success btn-sm float-end">Add</a>
				</div>
			</div>
		</div>
		<div class="card-body">
			<div class="table-responsive">
                <form action="">
                   <div class="row">
                    <div class="col-sm-4">
                    Minimum date:
                        <input type="text"  class="form-control" id="min_date" name="min">
                    </div>
                    <div class="col-sm-4">
                        Maximum date:
                        <input type="text"  class="form-control" id="max_date" name="max">
                    </div>
                    <div class="col-sm-4">

                        Visitor name:
                        <input type="text"  class="form-control" id="visitor_name1" name="visitor_name1">
                    </div>
                   </div>
                   <div class="row">

                    <div class="col-sm-4">
                        Visitor mobile:
                        <input type="text"  class="form-control" id="visitor_mobile1" name="visitor_mobile1">
                    </div>
                    <div class="col-sm-4">

                        Department:
                        <select name="dept" id="depart-dd"  class="form-control">
                            <option value="" selected>Null</option>
                        <?php $__currentLoopData = $dept; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option value="<?php echo e($department->department_name); ?>"><?php echo e($department->department_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    </div>

                        <div class="col-sm-4">
                       Visitor meet person name:
                        <select id="visitor_meet" name="visitor_meet" class="form-control ">

                        </select>
                        </div>
                   </div>
                   <div style="margin:5px 0px;">

                        <input type="reset"  class="btn btn-danger" value="Reset">
                   </div>

                </form>
				<table class="table table-bordered" id="visitor_table">
					
                    <thead>
						<tr>
							<th>Visitor Name</th>
                            <th>Visitor Mobile Number</th>
                            <th>Visitor Token</th>
							<th>Meet Person Name</th>
                            <th>Department</th>
							<th>In Time</th>
							<th>Out Time</th>
							<th>Status</th>
							<th>Enter By</th>
							
						</tr>
					</thead>
					<tbody>

                    </tbody>
                    
				</table>
			</div>
		</div>
	</div>
</div>
<script>
// $(document).ready(function(){

// 	var table = $('#visitor_table').DataTable({

// 		processing:true,
// 		serverSide:true,
// 		ajax:"<?php echo e(route('visitor.fetchall')); ?>",
// 		columns:[
// 			{
// 				data:'visitor_name',
// 				name: 'visitor_name'
// 			},
//             {
// 				data:'visitor_mobile_no',
// 				name:'visitor_mobile_no'
// 			},
//             {
// 				data:'visitor_token',
// 				name:'visitor_token'
// 			},
// 			{
// 				data: 'visitor_meet_person_name',
// 				name: 'visitor_meet_person_name'
// 			},
// 			{
// 				data:'visitor_department',
// 				name:'visitor_department'
// 			},
// 			{
// 				data:'visitor_enter_time',
// 				name: 'visitor_enter_time'
// 			},
// 			{
// 				data:'visitor_out_time',
// 				name:'visitor_out_time'
// 			},
// 			{
// 				data:'visitor_status',
// 				name:'visitor_status'
// 			},
// 			{
// 				data:'name',
// 				name:'name'
// 			},


// 			{
// 				data:'action',
// 				name:'action',
// 				orderable:false
// 			}
// 		]
// 	});

// });
var minDate, maxDate;

// Custom filtering function which will search data in column four between two values
$.fn.dataTable.ext.search.push(
    function( settings, data, dataIndex ) {
        var min = minDate.val();
        console.log(min);
        var max = maxDate.val();
        var date = new Date( data[5] );
        if (
            ( min === null && max === null ) ||
            ( min === null && date <= max ) ||
            ( min <= date   && max === null ) ||
            ( min <= date   && date <= max )
        ) {
            return true;
        }
        return false;
    }
);

$(document).ready(function() {

	$('#visitor_table').dataTable( {
		"ajax": "<?php echo e(route('visitor.fetchall')); ?>",
		"columns": [

        {
                data:'visitor_name',

		},
        {
			data:'visitor_mobile_no',

		},
        {
			data:'visitor_token',

		},
		{
			data: 'visitor_meet_person_name',

		},
		{
			data:'visitor_department',

        },
		{
				data:'visitor_enter_time',

		},
		{
			data:'visitor_out_time',

		},
			{
			data:'visitor_status',

		},
		{
				data:'visitor_enter_by',

		}


			// {			data:'action',
            //             orderable:false
			// }
		],
    });

    minDate = new DateTime($('#min_date'), {
        format: 'MMMM Do YYYY'
    });

    maxDate = new DateTime($('#max_date'), {
        format: 'MMMM Do YYYY'
    });
    var table = $('#visitor_table').DataTable();
    $("#min_date, #max_date").on('change', function () {
        console.log($("#min_date").val());
        table.draw();
    });

    // DataTables initialisation


    // Refilter the table
    console.log("|aa");

    // ///////////
    $("#depart-dd").change(function(){
    // alert("The text has been changed.");
    // console.log(11);
    $department=$(this).val();
    $("#visitor_meet").html('');
    $.ajax({
        type:'POST',
        // url:url('visitor_meet'),
        url: "<?php echo e(url('visitor_meet')); ?>",
        dataType:"json",
        // data:$department,
        data: {
            depart:$department,
            _token: '<?php echo e(csrf_token()); ?>'
        },
        success: function (result) {
        //    $("#msg").html(data.msg);
        $.each(result.dept, function (key, value) {
            // var nameArr = $(this).split(',');
            // console.log(nameArr);
            console.log(value.contact_person);
            console.log("////////////////");
            cont_per =value.contact_person.split(',');
            console.log(cont_per);
            console.log("////////////////");
            $('#visitor_meet').append('<option value="" selected>Null</option>');
            for(var i=0;i<cont_per.length;i++){
                // if(j==cont_per[i]){
            $("#visitor_meet").append('<option  value="' + cont_per[i] + '">' + cont_per[i] + '</option>');
                // }
            // else{
            // $("#visitor_meet").append('<option value="' + cont_per[i] + '">' + cont_per[i] + '</option>');
            // }
        }
                        });
    //         $('#visitor_meet').append($('<option>', {
    //     value: value.contact_person,
    //     text : value.contact_person
    // }));

        console.log(result.dept);
        }
     });
    });

    // ///////////////////
    // var table = $('#visitor_table').DataTable();

// #column3_search is a <input type="text"> element
$('#visitor_name1').on( 'keyup', function () {
    table
        .columns(0)
        .search( this.value )
        .draw();
} );
$('#visitor_mobile1').on( 'keyup', function () {
    table
        .columns(1)
        .search( this.value )
        .draw();
} );
$('#depart-dd').on( 'change', function () {
    table
        .columns(4)
        .search( this.value )
        .draw();
} );
$('#visitor_meet').on( 'change', function () {
    table
        .columns(3)
        .search( this.value )
        .draw();
} );

// $('#button_1').on('clicl',function(){
//     $("#max_date").html('');
//     $("#min_date").html('');
//     $("#visitor_meet").html('');
//     $("#depart-dd").html('');
// })

    // ///////////

    // each search1 filter
    // ///////////
    // $('.search1').each(function () {
    //     var title = $(this).text();
    //     $(this).html('<input type="text" placeholder="Search ' + title + '" />');
    // });

    // DataTable
    // var table = $('#visitor_table').DataTable({
    //     initComplete: function () {
    //         // Apply the search
    //         this.api()
    //             .columns()
    //             .every(function () {
    //                 var that = this;

    //                 $('input:text .search1', this).on('keyup change clear', function () {
    //                     if (that.search() !== this.value) {
    //                         that.search(this.value).draw();
    //                     }
    //                 });
    //             });
    //     },
    // });

});

//        initComplete: function () {
//             this.api().columns().every( function () {
//                 var column = this;
//                 var select = $('<select><option value=""></option></select>')
//                     .appendTo( $(column.footer()).empty() )
//                     .on( 'change', function () {
//                         var val = $.fn.dataTable.util.escapeRegex(
//                             $(this).val()
//                         );

//                         column
//                             .search( val ? '^'+val+'$' : '', true, false )
//                             .draw();
//                     } );

//                 column.data().unique().sort().each( function ( d, j ) {
//                     select.append( '<option value="'+d+'">'+d+'</option>' );
//                 } );
//             } );
//         }
// 	} );
// } );


// $(document).ready(function() {
//     // Create date inputs
//     minDate = new DateTime($('#min'), {
//         format: 'MMMM Do YYYY'
//     });

//     maxDate = new DateTime($('#max'), {
//         format: 'MMMM Do YYYY'
//     });

//     // DataTables initialisation
//     var table = $('#visitor_table').DataTable();

//     // Refilter the table
//     $('#min, #max').on('change', function () {
//         alert("haer")
//         console.log(minDate.val());
//         table.draw();
//     });
// });

// $('#min, #max').on('change', function () {
// var dateTimeMin = document.getElementById("min").value;
// var dateTimeMax = document.getElementById("max").value;
// var minDate=dateTimeMin;
// var maxDate=dateTimeMax;
//     // console.log("////////////Roshan dateTime="+dateTime);
// });

// console.log(minDate);
// var minDate, maxDate;

// // Custom filtering function which will search data in column four between two values
// $.fn.dataTable.ext.search.push(
//     function( settings, data, dataIndex ) {
//         var min = minDate.val();
//         // var min = minDate;
//         var max = maxDate.val();
//         // var max = maxDate;
//         // console.log("/////minDate="+minDate);
//          var date = new Date( data[5] );
//         // var date1 = new Date(data[5] );
//         // const year = date1.getFullYear();
//         // const month = date1.getMonth() + 1;
//         // const day = date1.getDate();
//         // const date = [year, month, day].join('-');
//         // console.log(date);
//         // console.log("////////////Roshan "+min);
//         if (
//             ( min === null && max === null ) ||
//             ( min === null && date <= max ) ||
//             ( min <= date   && max === null ) ||
//             ( min <= date   && date <= max )
//         ) {
//             return true;
//         }
//         return false;
//     }
// );

// // $('#min, #max').on('change', function () {
// // var dateTimeMin = document.getElementById("min").value;
// // var dateTimeMax = document.getElementById("max").value;
// // var minDate=dateTimeMin;
// // var maxDate=dateTimeMax;
// //     // console.log("////////////Roshan dateTime="+dateTime);
// // });

// $(document).ready(function() {
//     // Create date inputs
//     // $('#min, #max').on('change', function () {
//     minDate = new DateTime($('#min'), {
//         format: 'MMMM Do YYYY'
//     });

//     // var dateTime = document.getElementById("min").value;
//     // console.log("////////////Roshan dateTime="+dateTime);
// // // Use it here
//     // var countDownDate = new Date(dateTime);
//     // const year1 = countDownDate.getFullYear();
//     // console.log("year1 ="+year1);
//     //     const month1 = countDownDate.getMonth() + 1;
//     //     const day1 = countDownDate.getDate();
//     //     const date2 = [year1, month1, day1].join('-');
//     // console.log("////////////Roshan minDate "+date2);
//     maxDate = new DateTime($('#max'), {
//         format: 'MMMM Do YYYY'
//     });
//     // });
//     // DataTables initialisation
//     var table = $('#visitor_table').DataTable();

//     // Refilter the table
//     $('#min, #max').on('change', function () {
//         //////
//     //     var dateTimeMin = document.getElementById("min").value;
//     // var dateTimeMax = document.getElementById("max").value;
//     // var minDate=dateTimeMin;
//     // var maxDate=dateTimeMax;
//         //////
//         table.draw();
//     });
// });



// $("document").ready(function(){
//     setTimeout(function(){
//        $("div.alert").remove();
//     }, 5000 ); // 5 secs

// });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\visitor_management\resources\views/visitor.blade.php ENDPATH**/ ?>