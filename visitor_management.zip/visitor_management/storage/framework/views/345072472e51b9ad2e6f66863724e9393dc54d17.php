

<?php $__env->startSection('content'); ?>

<h2 class="mt-3">Sub User Management</h2>
<nav aria-label="breadcrumb">
  	<ol class="breadcrumb">
    	<li class="breadcrumb-item"><a href="/dashboard">Dashboard</a></li>
    	<li class="breadcrumb-item"><a href="/sub_user">Sub Management</a></li>
    	<li class="breadcrumb-item active">Edit Sub User</li>
  	</ol>
</nav>

<div class="row mt-4">
	<div class="col-md-4">
		<div class="card">
			<div class="card-header">Edit Sub User</div>
			<div class="card-body">
				<form method="POST" action="<?php echo e(route('sub_user.edit_validation')); ?>">
					<?php echo csrf_field(); ?>
					<div class="form-group mb-3">
		        		<label><b>User Name</b></label>
		        		<input type="text" name="name" class="form-control" placeholder="Name" value="<?php echo e($data->name); ?>" />
		        		<?php if($errors->has('name')): ?>
		        		<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
		        		<?php endif; ?>
		        	</div>
		        	<div class="form-group mb-3">
		        		<label><b>User Email</b></label>
		        		<input type="text" name="email" class="form-control" placeholder="Email" value="<?php echo e($data->email); ?>">
		        		<?php if($errors->has('email')): ?>
		        			<span class="text-danger"><?php echo e($errors->first('email')); ?></span>
		        		<?php endif; ?>
		        	</div>
		        	<div class="form-group mb-3">
		        		<label><b>Password</b></label>
		        		<input type="password" name="password" class="form-control" placeholder="Password">
		        		<?php if($errors->has('password')): ?>
		        			<span class="text-danger"><?php echo e($errors->first('password')); ?></span>
		        		<?php endif; ?>
		        	</div>
		        	<div class="form-group mb-3">
		        		<input type="hidden" name="hidden_id" value="<?php echo e($data->id); ?>" />
		        		<input type="submit" class="btn btn-primary" value="Edit" />
		        	</div>
				</form>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tutorial\visitor_management\resources\views/edit_sub_user.blade.php ENDPATH**/ ?>