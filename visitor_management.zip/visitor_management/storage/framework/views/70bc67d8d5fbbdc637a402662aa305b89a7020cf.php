<?php $__env->startSection('content'); ?>

<h2 class="mt-5">Visitor Management</h2>
<nav aria-label="breadcrumb">
  	<ol class="breadcrumb">
    	<li class="breadcrumb-item"><a href="/information">Dashboard</a></li>
    	<li class="breadcrumb-item"><a href="/visitor">Visitor</a></li>
    	<li class="breadcrumb-item active">Add New Visitor</li>
  	</ol>
</nav>


<div class="row mt-4">
	<div class="col-md-12">
		<div class="card">
			<div class="card-header">Add New Visitor</div>
			<div class="card-body">
				<form method="POST" action="<?php echo e($url); ?>">
                    
                        
					<?php echo csrf_field(); ?>
                    <div class="row">
					<div class="form-group mb-3 col-4">
		        		<label><b>Visitor Name *</b></label>
		        		<input type="text" name="name" class="form-control " <?php if($url==route('visitor_create')): ?><?php echo e(""); ?><?php else: ?><?php echo e("readonly"); ?><?php endif; ?> placeholder="Name" value="<?php echo e(old('name', $visitor->visitor_name)); ?>" />
		        		<?php if($errors->has('name')): ?>
		        		<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
		        		<?php endif; ?>
		        	</div>

		        	<div class="form-group mb-3 col-4">
		        		<label><b>Visitor Email *</b></label>
		        		<input type="text" name="visitor_email" class="form-control " <?php if($url==route('visitor_create')): ?><?php echo e(""); ?><?php else: ?><?php echo e("readonly"); ?><?php endif; ?> placeholder="Email" value="<?php echo e(old('visitor_email',$visitor->visitor_email)); ?>">
		        		<?php if($errors->has('visitor_email')): ?>
		        			<span class="text-danger"><?php echo e($errors->first('visitor_email')); ?></span>
		        		<?php endif; ?>
		        	</div>
                    <div class="form-group mb-3 col-4">
		        		<label><b>Visitor Mobile Number *</b>(9 digits only)</label>

		        		<input type="number" name="mob_num" class="form-control " <?php if($url==route('visitor_create')): ?><?php echo e(""); ?><?php else: ?><?php echo e("readonly"); ?><?php endif; ?> placeholder="Mobile Number" value="<?php echo e(old('mob_num',$visitor->visitor_mobile_no)); ?>">
		        		<?php if($errors->has('mob_num')): ?>
		        			<span class="text-danger"><?php echo e($errors->first('mob_num')); ?></span>
		        		<?php endif; ?>
		        	</div>
                </div>
                <div class="row">
                    <div class="form-group mb-3 col-4">
		        		<label><b>Visitor Address *</b></label>
		        		
		        		<input type="text" name="address" class="form-control " <?php if($url==route('visitor_create')): ?><?php echo e(""); ?><?php else: ?><?php echo e("readonly"); ?><?php endif; ?> placeholder="Visitor address" value="<?php echo e(old('address',$visitor->visitor_address)); ?>">
                        <?php if($errors->has('address')): ?>
		        			<span class="text-danger"><?php echo e($errors->first('address')); ?></span>
		        		<?php endif; ?>
		        	</div>
                    
                    <div class="form-group mb-3 col-4">
		        		<label><b>Visitor Department *</b></label>
		        		
                        
                            <select name="dept" id="depart-dd"  class="form-control " >
                                <option value="" <?php if($url==route('visitor_create')): ?><?php echo e(""); ?><?php else: ?><?php echo e("disabled"); ?><?php endif; ?>>Null</option>
                            <?php $__currentLoopData = $dept; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(old('dept',$visitor->visitor_department)==$department->department_name ): ?>
                                <option value="<?php echo e($department->department_name); ?>" selected><?php echo e($department->department_name); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($department->department_name); ?>" <?php if($url==route('visitor_create')): ?><?php echo e(""); ?><?php else: ?><?php echo e("disabled"); ?><?php endif; ?>><?php echo e($department->department_name); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
		        		<?php if($errors->has('dept')): ?>
		        			<span class="text-danger"><?php echo e($errors->first('dept')); ?></span>
		        		<?php endif; ?>
		        	</div>
                    <div class="form-group mb-3 col-4">
		        		<label><b>Visitor meet person name *</b></label>
		        		

                            <select id="visitor_meet" name="visitor_meet" class="form-control ">
                            </select>
                    

                        <?php if($errors->has('visitor_meet')): ?>
		        			<span class="text-danger"><?php echo e($errors->first('visitor_meet')); ?></span>
		        		<?php endif; ?>
		        	</div>
                </div>
                    
                    <div class="row">
                    <div class="form-group mb-3 col-4">
		        		<label><b>Visitor Out Status *</b></label>
                        <br>
		        		
		        		<p fontsize="10px;">Yes
                        <input name="out_time" class="visitor_out_status" type="checkbox" value="Yes">
                        No
                        <input name="out_time" class="visitor_out_status" type="checkbox" value="No">
                        <?php if($errors->has('out_time')): ?>
		        			<span class="text-danger"><?php echo e($errors->first('out_time')); ?></span>
		        		<?php endif; ?>
                        </p>
		        	</div>

                    <div class="form-group mb-3 col-4">
		        		<label><b>Visitor Reason To meet *</b></label>
		        		<input type="text" name="reason" class="form-control " <?php if($url==route('visitor_create')): ?><?php echo e(""); ?><?php else: ?><?php echo e("readonly"); ?><?php endif; ?> placeholder="Visitor reason to meet" value="<?php echo e(old('reason',$visitor->visitor_reason_to_meet)); ?>">
		        		<?php if($errors->has('reason')): ?>
		        			<span class="text-danger"><?php echo e($errors->first('reason')); ?></span>
		        		<?php endif; ?>
		        	</div>
                    <div class="form-group mb-3 col-4">
		        		<label><b>Visitor Token *</b></label>
		        		  <select name="visitor_token" id="visitor_token"  class="form-control " >
                                <option value="<?php echo e(old('visitor_token',$visitor->visitor_token)); ?>" <?php if($visitor->visitor_token==Null): ?><?php echo e("hidden"); ?><?php else: ?><?php echo e(""); ?><?php endif; ?> selected><?php echo e(old('visitor_token',$visitor->visitor_token)); ?></option>

                            <?php for($i=1;$i<=30;$i++): ?>
                            <?php echo e($count=0); ?>

                            <?php $__currentLoopData = $visitor_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_all): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($v_all->visitor_token == $i): ?>

                               <?php echo e($count++ ); ?>

                            <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($count<1): ?>

                                <option value="<?php echo e($i); ?>" <?php if($url==route('visitor_create')): ?><?php echo e(""); ?><?php else: ?><?php echo e("disabled"); ?><?php endif; ?>><?php echo e($i); ?></option>
                            <?php endif; ?>
                            <?php endfor; ?>
                        </select>
		        		<?php if($errors->has('visitor_token')): ?>
		        			<span class="text-danger"><?php echo e($errors->first('visitor_token')); ?></span>
		        		<?php endif; ?>
		        	</div>
                </div>
		        	
		        	<div class="form-group mb-3">
		        		<input type="submit" class="btn btn-primary" value="Save" />
		        	</div>
				</form>
			</div>
		</div>
	</div>
</div>
<script>
$(document).ready(function(){
    $("#depart-dd").change(function(){
    // alert("The text has been changed.");
    // console.log(11);
    $department=$(this).val();
    $("#visitor_meet").html('');
    $.ajax({
        type:'POST',
        // url:url('visitor_meet'),
        url: "<?php echo e(url('visitor_meet')); ?>",
        dataType:"json",
        // data:$department,
        data: {
            depart:$department,
            _token: '<?php echo e(csrf_token()); ?>'
        },
        success: function (result) {
        //    $("#msg").html(data.msg);
        $.each(result.dept, function (key, value) {
            // var nameArr = $(this).split(',');
            // console.log(nameArr);
            console.log(value.contact_person);
            console.log("////////////////");
            cont_per =value.contact_person.split(',');
            console.log(cont_per);
            console.log("////////////////");
            // var j=<?php $visitor->visitor_meet_person_name ?>;
            // var j="<?php echo $visitor->visitor_meet_person_name; ?>" ;
            // console.log(j);
            for(var i=0;i<cont_per.length;i++){
                // if(j==cont_per[i]){
            $("#visitor_meet").append('<option  value="' + cont_per[i] + '">' + cont_per[i] + '</option>');
                // }
            // else{
            // $("#visitor_meet").append('<option value="' + cont_per[i] + '">' + cont_per[i] + '</option>');
            // }
        }
                        });
    //         $('#visitor_meet').append($('<option>', {
    //     value: value.contact_person,
    //     text : value.contact_person
    // }));

        console.log(result.dept);
        }
     }); 
  });

  $('.visitor_out_status').on('change', function() {
		    $('.visitor_out_status').not(this).prop('checked', false);
		});

// ///////////////

});

//////////////////////
$(document).ready(function(){
    // $("#depart-dd").change(function(){
    // alert("The text has been changed.");
    // console.log(11);
    // var v_per="<?php echo $visitor->visitor_meet_person_name; ?>" ;
    // console.log(v_per);
    $department=$('#depart-dd').val();
    // if($department==)
    $("#visitor_meet").html('');
    $.ajax({
        type:'POST',
        // url:url('visitor_meet'),
        url: "<?php echo e(url('visitor_meet')); ?>",
        dataType:"json",
        data:$department,
        data: {
            depart:$department,
            _token: '<?php echo e(csrf_token()); ?>'
        },
        success: function (result) {
        //    $("#msg").html(data.msg);
        $.each(result.dept, function (key, value) {
            // var nameArr = $(this).split(',');
            // console.log(nameArr);
            console.log(value.contact_person);
            console.log("////////////////");
            cont_per =value.contact_person.split(',');
            console.log(cont_per);
            console.log("////////////////");
            // var j=<?php $visitor->visitor_meet_person_name ?>;
            var j="<?php echo $visitor->visitor_meet_person_name; ?>" ;
            var dis="<?php if($url==route('visitor_create')){ echo " "; } else{ echo "disabled";} ?>";
            console.log("/////hello roshan////"+dis +"//////////////////"+ j);
            for(var i=0;i<cont_per.length;i++){
                console.log(cont_per[i]);
                if(j==cont_per[i]){

            $("#visitor_meet").append('<option selected value="' + cont_per[i] + '">' + cont_per[i] + '</option>');
                }
            else{
            $("#visitor_meet").append('<option '+ dis +' value="' + cont_per[i] + '" >' + cont_per[i] + '</option>');
            }
        }
                        });
    //         $('#visitor_meet').append($('<option>', {
    //     value: value.contact_person,
    //     text : value.contact_person
    // }));

        console.log(result.dept);
        }
     });

});

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\visitor_management\resources\views/visitor_add.blade.php ENDPATH**/ ?>