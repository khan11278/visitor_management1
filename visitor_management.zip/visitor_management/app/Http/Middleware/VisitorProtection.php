<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\Visitor;
use Illuminate\Support\Facades\Auth;

class VisitorProtection
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
         // dd(auth()->user()->id);
         $id= Auth::user()->id;
        //  dd($id);
         $visitor=Visitor::where('id',$request->route('id'))->get();
        //  dd($visitor);
        foreach ($visitor as $visit) {
        // foreach ( $visitor as $visit )
         if (  $id == $visit->visitor_enter_by || $id==1 ) {
            // return redirect('/');
            return $next($request);

        }
    }

    return redirect('/dashboard');
    // return $next($request);

    }
}
