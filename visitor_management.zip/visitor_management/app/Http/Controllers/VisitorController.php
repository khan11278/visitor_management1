<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Visitor;
use App\Models\Department;
use Carbon\Carbon;
use DataTables;
use Illuminate\Support\Facades\Auth;
// use DateTime;

class VisitorController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    function index()
    {
        $visitor=Visitor::all();
        $dept=Department::all();
        $data=compact('visitor','dept');
        return view('visitor')->with($data);
    }

    //  function fetch_all(Request $request)
    // {
        // $records=Visitor::all();

        // foreach($records as $record){
        //     $visitor_name = $record->visitor_name;
        //     $visitor_mobile_no = $record->visitor_mobile_no;
        //     $visitor_token = $record->visitor_token;
        //     $visitor_meet_person_name = $record->visitor_meet_person_name;
        //     $visitor_department = $record->visitor_department;
        //     $enter = explode(' ',$record->visitor_enter_time);
        //     $visitor_enter_time=$enter[0];
        //     $visitor_out_time = $record->visitor_out_time;
        //     $visitor_status = $record->visitor_status;
        //     $visitor_enter_by = $record->visitor_enter_by;

        //     $data_arr[] = array(
        //       "visitor_name" => $visitor_name,
        //       "visitor_mobile_no" => $visitor_mobile_no,
        //       "visitor_token" => $visitor_token,
        //       "visitor_meet_person_name" => $visitor_meet_person_name,
        //       "visitor_department" => $visitor_department,
        //       "visitor_enter_time" => $visitor_enter_time,
        //       "visitor_out_time" => $visitor_out_time,
        //       "visitor_status" => $visitor_status,
        //       "visitor_enter_by" => $visitor_enter_by,
        //     );
        //  }
        //  $response = array(
        //     "aaData" => $data_arr
        // );
        // echo json_encode($response);
        // exit;

    //     if($request->ajax())
    //     {
    //         $query = Visitor::join('users', 'users.id', '=', 'visitors.visitor_enter_by');

    //         if(Auth::user()->type == 'User')
    //         {
    //             $query->where('visitors.visitor_enter_by', '=', Auth::user()->id);
    //         }

    //         $data = $query->get(['visitors.visitor_name','visitor_mobile_no','visitor_token', 'visitors.visitor_meet_person_name', 'visitors.visitor_department', 'visitors.visitor_enter_time', 'visitors.visitor_out_time', 'visitors.visitor_status', 'users.name', 'visitors.id']);

    //         return DataTables::of($data)
    //             ->addIndexColumn()
    //             ->editColumn('visitor_status', function($row){
    //                 if($row->visitor_status == 'In')
    //                 {
    //                     return '<span class="badge bg-success">In</span>';
    //                 }
    //                 else
    //                 {
    //                     return '<span class="badge bg-danger">Out</span>';
    //                 }
    //             })
    //             ->escapeColumns('visitor_status')
    //             ->addColumn('action', function($row){
    //                 if($row->visitor_status == 'In')
    //                 {
    //                     // return '<a href="/visitor/view/'.$row->id.'" class="btn btn-info btn-sm">View</a>&nbsp;<a href="/visitor/edit/'.$row->id.'" class="btn btn-primary btn-sm">Edit</a>&nbsp;<a href="/visitor/delete/'.$row->id.'" class="btn btn-danger btn-sm delete">Delete</a>';
    //                     // return '<a href="/visitor/edit/'.$row->id.'" class="btn btn-primary btn-sm">Edit</a>&nbsp;<a href="/visitor/delete/'.$row->id.'" class="btn btn-danger btn-sm delete">Delete</a>';
    //                     return '<a href="/visitor/edit/'.$row->id.'" class="btn btn-primary btn-sm">Edit</a>';

    //                 }
    //                 else
    //                 {
    //                    // return '<a href="/visitor/view/'.$row->id.'" class="btn btn-info btn-sm">View</a>&nbsp;<a href="/visitor/delete/'.$row->id.'" class="btn btn-danger btn-sm delete">Delete</a>';
    //                     // return '<a href="/visitor/delete/'.$row->id.'" class="btn btn-danger btn-sm delete">Delete</a>';
    //                     return '';
    //                 }
    //             })
    //             ->rawColumns(['action'])
    //             ->make(true);
    //     }
    // }
    public function add(){
        $visitor=new Visitor();
        $visitor_all=Visitor::all();
        // dd($visitor_all);
        $readonly="";
        $dept =Department::all();
        $url=route('visitor_create');
        $disabled1="";
        $data=compact('dept','visitor','url','visitor_all','readonly','disabled1');
        return view('visitor_add')->with($data);
    }
    public function visitor_meet(Request $request){
        $data['dept'] = Department::where("department_name",$request->depart)->get(["contact_person"]);
        return response()->json($data);

    }

    public function create(Request $request){
        // dd($request);
        $request->validate([
            'name'          =>  'required',
            'visitor_email' => 'required|email|unique:visitors',
            'mob_num'       => 'required|regex:/[0-9]{9}/',
            'address'       => 'required|string|max:255',
            'visitor_meet'  => 'required|string|max:255',
            'dept'          => 'required|string|max:255',
            'reason'        => 'required|string|max:255',
            // 'enter_time'    =>'required',
            'out_time'      =>'required',
            // 'password'      =>  'required|min:6',
        ]);

        $visitor =new Visitor();
            $visitor->visitor_name = $request['name'];
             $visitor->visitor_email     = $request['visitor_email'];
            // 'password' = Hash::make($request['password']);
            // 'type'     = 'User'
            $visitor->visitor_mobile_no    = $request['mob_num'];
            $visitor->visitor_address    = $request['address'];
            // dd($request['visitor_meet']);
            $visitor->visitor_meet_person_name    = $request['visitor_meet'];
            $visitor->visitor_department    = $request['dept'];
            $visitor->visitor_reason_to_meet    = $request['reason'];
            // 'visitor_enter_time'    = Carbon::now()->toDateTimeString();
            // $visitor->visitor_enter_time    =$request['enter_time'] ;
            $visitor->visitor_enter_time    =Carbon::now() ;
            $visitor->visitor_outing_remark    = "null";
            if($request['out_time']=="Yes"){
            $visitor->visitor_out_time    =Carbon::now();
            }
            else{
                $visitor->visitor_out_time    =NUll;
            }
            if($visitor->visitor_out_time== NUll){
            $visitor->visitor_status='In';
            }
            else{
                $visitor->visitor_status='Out';
            }
            $visitor->visitor_enter_by    = Auth::user()->id;
            $visitor->visitor_token=$request['visitor_token'];
         $visitor->save();
         session()->flash('success', 'You have Successfully Registered');

        // dd("success");
        return redirect('/visitor');

    }

    public function edit($id){
        $visitor=Visitor::find($id);
        // dd($visitor);
        $dept=Department::all();
        $visitor_all=Visitor::all();
        $url=url('/visitor/update').'/'.$id;
        $readonly="readonly";
        $disabled1='disabled';
        $data=compact('visitor','dept','url','visitor_all','readonly','disabled1');
        return view('visitor_add')->with($data);
    }
    public function update($id,Request $request ){
        $request->validate([
            // 'name'          =>  'required',
            // // 'visitor_email' => 'required|email|unique:visitor',
            // // 'mob_num'       => 'required|integer|max:9',
            // 'address'       => 'required|string|max:255',
            // // 'visitor_meet'  => 'required|string|max:255',
            // 'dept'          => 'required|string|max:255',
            // 'reason'        => 'required|string|max:255',

            // 'password'      =>  'required|min:6',
            'name'          =>  'required',
            'visitor_email' => 'required|email',
            'mob_num'       => 'required|regex:/[0-9]{9}/',
            'address'       => 'required|string|max:255',
            'visitor_meet'  => 'required|string|max:255',
            'dept'          => 'required|string|max:255',
            'reason'        => 'required|string|max:255',
            // 'enter_time'    =>'required',
            'out_time'      =>'required',
        ]);

        $visitor =Visitor::find($id);
            $visitor->visitor_name = $request['name'];
             $visitor->visitor_email     = $request['visitor_email'];
            // 'password' = Hash::make($request['password']);
            // 'type'     = 'User'
            $visitor->visitor_mobile_no    = $request['mob_num'];
            $visitor->visitor_address    = $request['address'];
            // dd($request['visitor_meet']);
            $visitor->visitor_meet_person_name    = $request['visitor_meet'];
            $visitor->visitor_department    = $request['dept'];
            $visitor->visitor_reason_to_meet    = $request['reason'];
            // 'visitor_enter_time'    = Carbon::now()->toDateTimeString();
            $visitor->visitor_enter_time    =$visitor->visitor_enter_time;
            $visitor->visitor_outing_remark    = "null";
            if($request['out_time']=="Yes"){
            $visitor->visitor_out_time    =Carbon::now();
            $visitor->visitor_token=Null;
            }
            else{
                $visitor->visitor_out_time    =NUll;
                $visitor->visitor_token=$request['visitor_token'];
            }
            if($visitor->visitor_out_time== NUll){
                $visitor->visitor_status='In';
            }
            else{
                $visitor->visitor_status='Out';
            }
            // $visitor->visitor_status='In';
            $visitor->visitor_enter_by    = Auth::user()->id;
            $visitor->save();
            // dd("success");
            session()->flash('success1', 'You have Successfully Updated');
            return view('/visitor');
    }
    public function delete($id){
        $visitor=Visitor::find($id);
        $visitor->delete($id);
        return redirect()->back();
    }
    public function entry($p){
        $visitor=Visitor::find($p);
        $visitor->visitor_department=Null;
        $visitor->visitor_meet_person_name=Null;
        $visitor->visitor_reason_to_meet=Null;
        $visitor->visitor_token=Null;
        $dept=Department::all();
        $readonly="";
        $disabled1="";
        $visitor_all=Visitor::all();
        $url=route('visitor_entry_create');
        return view('visitor_add')->with(compact('visitor','url','dept','visitor_all','readonly','disabled1'));
    }
    public function entry_create(Request $request){
        // dd("hello how are you");
        $request->validate([
            'name'          =>  'required',
            'visitor_email' => 'required|email',
            'mob_num'       => 'required|regex:/[0-9]{9}/',
            'address'       => 'required|string|max:255',
            'visitor_meet'  => 'required|string|max:255',
            'dept'          => 'required|string|max:255',
            'reason'        => 'required|string|max:255',
            // 'enter_time'    =>'required',
            'out_time'      =>'required',
            // 'password'      =>  'required|min:6',
        ]);

        $visitor =new Visitor();
            $visitor->visitor_name = $request['name'];
             $visitor->visitor_email     = $request['visitor_email'];
            // 'password' = Hash::make($request['password']);
            // 'type'     = 'User'
            $visitor->visitor_mobile_no    = $request['mob_num'];
            $visitor->visitor_address    = $request['address'];
            // dd($request['visitor_meet']);
            $visitor->visitor_meet_person_name    = $request['visitor_meet'];
            $visitor->visitor_department    = $request['dept'];
            $visitor->visitor_reason_to_meet    = $request['reason'];
            // 'visitor_enter_time'    = Carbon::now()->toDateTimeString();
            // $visitor->visitor_enter_time    =$request['enter_time'] ;
            $visitor->visitor_enter_time    =Carbon::now() ;
            $visitor->visitor_outing_remark    = "null";
            if($request['out_time']=="Yes"){
            $visitor->visitor_out_time    =Carbon::now();
            }
            else{
                $visitor->visitor_out_time    =NUll;
            }
            if($visitor->visitor_out_time== NUll){
            $visitor->visitor_status='In';
            }
            else{
                $visitor->visitor_status='Out';
            }
            $visitor->visitor_enter_by    = Auth::user()->id;
            $visitor->visitor_token=$request['visitor_token'];
         $visitor->save();
         session()->flash('success', 'You have Successfully Registered');

        // dd("success");
        return redirect('/visitor');

    }
    public function visitor_out($id){
        // dd("hello");
        $visitor =Visitor::find($id);

            $visitor->visitor_out_time    =Carbon::now();
            $visitor->visitor_token=Null;
            // $visitor->visitor_department=$visitor->visitor_department;
            $visitor->save();
            // dd("success");
            // $dept=Department::all();
            session()->flash('success1', 'The Out status has been updated');
            return redirect('/visitor');
    }

}

