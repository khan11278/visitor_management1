<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Employee;
use DataTables;
use App\Models\Department;

class EmployeeController extends Controller
{
    public function employee(){
        $employee=Employee::all();
        // $dept=Department::all();
        return view('employee')->with(compact('employee'));
    }
    public function employee_add(){
        $department =Department::all();
        $count=$department->count();
        $emp_dept=[];
        $url=route('employee_create');
        $employee=new Employee;
        $data= compact('department','count','employee','emp_dept','url');
        return view('employee_add')->with($data);
    }
    public function employee_create(Request $request){
        // dd($request['dept']);
        $request->validate([
            'name'          =>  'required',
            'email'         => 'required|email',
            // 'dept'          => 'required|string|max:255',
        ]);
        $input = $request->all();
        foreach($input['dept'] as $depart1){
            // dd($depart1);
        $employee =new Employee();
        $employee->name=$request['name'];
        $employee->email=$request['email'];
        $employee->department_id=$depart1;
        // $input = $request->all();

        // $depart_name1="";

                // $depart_single= Department::where('id',$depart1)->first();
                // $depart_single->contact_person=$depart_single->contact_person.",".$request['name'];
                // dd($depart_single->department_name);
                // $depart_name1=$depart_name1.",".$depart_single->department_name;
                // $depart1->department;

                $employee->save();
                }

                // $substring=substr( $depart_name1, 1);
                // $employee->department_name=$substring;
                // $employee->save();
                session()->flash('employee_register', 'You have Successfully Registered');
                return redirect('employee');
            }

    // function fetch_all(Request $request)
    // {
    //     if($request->ajax())
    //     {
    //         $data = Employee::latest()->get();
    //         return DataTables::of($data)
    //             ->addIndexColumn()
    //             ->addColumn('action', function($row){
    //                 return '<a href="/employee/edit/'.$row->id.'" class="btn btn-primary btn-sm">Edit</a>&nbsp;<a href="/employee/delete/'.$row->id.'" class="btn btn-danger btn-sm delete">Delete</a>';
    //             })
    //             ->rawColumns(['action'])
    //             ->make(true);
    //     }
    // }
    public function employee_edit($id){
        $employee=Employee::find($id);
        // dd($employee);
        $emp_dept=explode(",",$employee->department_name);
        // dd($emp_dept);
        $url=url('/employee/update').'/'.$id;
        $department =Department::all();
        $count=$department->count();
        $data= compact('department','count','employee','emp_dept','url');
        return view('employee_add')->with($data);
    }
    public function employee_update(Request $request,$id){
        $request->validate([

            'name'          =>  'required',
            'email'         => 'required|email',

        ]);
        $employee =Employee::find($id);
        $employee->name=$request['name'];
        $employee->email=$request['email'];
        $input = $request->all();

        $depart_name1="";
        foreach($input['dept'] as $depart1){
                $depart_single= Department::where('id',$depart1)->first();
                $depart_single->contact_person=$depart_single->contact_person.",".$request['name'];
                // dd($depart_single->department_name);
                $depart_name1=$depart_name1.",".$depart_single->department_name;

                $depart_single->save();
                }
                // echo "$depart_name1";
                // dd();
                // $arrComma =implode(",",$depart_name1);
                $substring=substr( $depart_name1, 1);
                $employee->department_name=$substring;
                // dd("Hello Roshan Khan");
                $employee->save();
                session()->flash('employee_update', 'You have Successfully Updated');
                return redirect('employee');
    }
}
