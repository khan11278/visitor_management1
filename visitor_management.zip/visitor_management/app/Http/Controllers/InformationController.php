<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Visitor;
use Carbon\Carbon;

class InformationController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function information(){
        if(Auth::user()->type =='Admin'){
        $weekCount = Visitor::whereDate('created_at', '>=',Carbon::now()->addWeeks(-1))->count();
        // $yesterdayCount=Visitor::whereDate('created_at', '>=',Carbon::now()->addDays(-1))->count();
        $yesterdayCount=Visitor::where('created_at', '>=', Carbon::now()->yesterday())->where('created_at', '<=', Carbon::now()->startOfDay())->count();
        $todayCount=Visitor::whereDate('created_at', '>=',Carbon::now()->addDays(0))->count();
        $totalCount=Visitor::whereDate('created_at', '<=',Carbon::now())->count();
        }
        else{
            $weekCount = Visitor::where('visitor_enter_by', '=',Auth::user()->id)->whereDate('created_at', '>=',Carbon::now()->addWeeks(-1))->count();
            // $yesterdayCount=Visitor::where('visitor_enter_by', '=',Auth::user()->id)->whereDate('created_at', '>=',Carbon::now()->addDays(-1))->count();
            $yesterdayCount=Visitor::where('visitor_enter_by', '=',Auth::user()->id)->where('created_at', '>=', Carbon::now()->yesterday())->where('created_at', '<=', Carbon::now()->startOfDay())->count();
            $todayCount=Visitor::where('visitor_enter_by', '=',Auth::user()->id)->whereDate('created_at', '>=',Carbon::now()->addDays(0))->count();
            $totalCount=Visitor::where('visitor_enter_by', '=',Auth::user()->id)->whereDate('created_at', '<=',Carbon::now())->count();

        }
        $data=compact('weekCount','yesterdayCount','todayCount','totalCount');
        return view('information')->with($data);
    }
}
