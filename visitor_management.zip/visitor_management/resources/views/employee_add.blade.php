@extends('dashboard')

@section('content')


<h2 class="mt-5">Employee Management</h2>
<nav aria-label="breadcrumb">
  	<ol class="breadcrumb">
    	<li class="breadcrumb-item"><a href="/information">Dashboard</a></li>
    	<li class="breadcrumb-item active"><a href="/employee">Employee Add</a></li>
    	{{-- <li class="breadcrumb-item active">Add New Sub User</li> --}}
  	</ol>
</nav>
<div class="row mt-4">
	<div class="col-md-4">
		<div class="card">
			<div class="card-header">Add New User</div>
			<div class="card-body">
				<form method="POST" action="{{ $url }}">
					@csrf
					<div class="form-group mb-3">
		        		<label><b>Employee Name *</b></label>
		        		<input type="text" name="name" class="form-control" value="{{old('name', $employee->name)}}" placeholder="Name" />
		        		@if($errors->has('name'))
		        		<span class="text-danger">{{ $errors->first('name') }}</span>
		        		@endif
		        	</div>
		        	<div class="form-group mb-3">
		        		<label><b>Employee Email *</b></label>
		        		<input type="text" name="email" class="form-control" value="{{old('name', $employee->email)}}" placeholder="Email">
		        		@if($errors->has('email'))
		        			<span class="text-danger">{{ $errors->first('email') }}</span>
		        		@endif
		        	</div>
                    {{-- <div class="form-group mb-3">
		        		<label><b>Employee Department*</b></label>
		        		<input type="text" name="dept" class="form-control" placeholder="Employee Department">
		        		@if($errors->has('dept'))
		        			<span class="text-danger">{{ $errors->first('dept') }}</span>
		        		@endif
		        	</div> --}}
                    <div class="form-group mb-3">
		        		<label><b>Employee department *</b></label>
                        <br>
                        {{-- <b> {{$employee->department['department_name']}}</b> --}}
                        <p fontsize="10px;">
                        @foreach($department as $dept)
		        		 <small>{{$dept->department_name}}</small>&nbsp;
                        <input name="dept[]"  type="checkbox" {{ in_array($dept->department_name, $emp_dept) ? 'checked' : '' }} value="{{$dept->id}}">

                        @if($errors->has('dept'))
		        			<span class="text-danger">{{ $errors->first('dept') }}</span>
		        		@endif
                            <br>
                        @endforeach
                    </p>
		        	</div>
		        	<div class="form-group mb-3">
		        		<input type="submit" class="btn btn-primary" value="Add" />
		        	</div>
				</form>
			</div>
		</div>
	</div>
</div>

@endsection
